# template-lib-crate

> [ibuidl discord](https://discord.com/invite/ZMTPBdxw2W)

A comprehensive template of lib crate!
